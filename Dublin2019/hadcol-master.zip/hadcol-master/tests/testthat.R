library(testthat)
library(addcol)

test_check("hadcol")
